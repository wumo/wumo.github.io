---
title:  "CPS Promise Monad FSM"
tags:  ["functional programming","monad","cps","promise","continuation"]
---


<!--more-->

ref [What is continuation-passing style in functional programming?](https://www.quora.com/What-is-continuation-passing-style-in-functional-programming)