---
title: Emoji Test
tags:
---

This is an emoji test. :smile: lol.

See emoji cheat sheet for more detail :wink: : <https://www.webpagefx.com/tools/emoji-cheat-sheet/>.

:bowtie::smile::laughing::blush::smiley::relaxed::smirk:
:heart_eyes::kissing_heart::kissing_closed_eyes::flushed::relieved::satisfied::grin:
