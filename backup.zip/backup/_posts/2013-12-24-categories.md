---
title: Categories
date: 2013-12-24 23:30:09
categories:
- Foo
- Bar
- Baz
---

This post contains 3 categories. Make sure your theme can display all of the categories.
